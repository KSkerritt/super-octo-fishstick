function pop() {
    alert("We want to make your carnival experience hassle free from long lines and traffic and for your convenience, we may offer delivery of costumes to your doorstep and also at select drop-off locations in some areas.");
  }
