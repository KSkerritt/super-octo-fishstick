// var idf = document.getElementById("Identification");
// const ida = document.querySelector(".buttonui label");

// // idf.addEventListener("click", () => {
// //   idf.classlist.toggle("active");
// // });

// document
//   .getElementById("Identification")
//   .addEventListener("click", function () {
//     ida.classlist.toggle("active");
//   });


function valid() {
  alert("Upload Successful.");
}

function valrc() {
  alert("Upload Successful.");
}